


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login/SignUp</title>
</head>
<body>
    <input type="radio" id="chk1" name="a1" style="display:none;">
    <input type="radio" id="chk2" name="a1" style="display:none;">
    <div class="box">

        <div class="a">
            <label for="chkl">Login</label>
            <label for="chk2" id="sup">Sign up</label>
            <link rel="stylesheet" type="text/css" href="signup.css">
        </div>
        <div class="b">
            <form action="" class="frm">
                <h6 class="title">SIGN-UP FORM</h6>
                <input type="text" placeholder="Enter Full Name">
                <input type="text" placeholder="Enter Address">
                <input type="text" placeholder="Enter Email Address">
                <input type="text" placeholder="Enter Password">
                <input type="text" placeholder="Confirm Password">
                <input type="button" value="Sign up" id="btn">
                <label for="chk1" id="btm">Login here</label>
            </form>
        </div>
        <div class="c">
            <form action="" class="frm">
                <br><br><br><br>
                <h6 class="title">LOGIN FORM</h6>
                <input type="text" placeholder=" Email ">
                <input type="text" placeholder="Enter Password">
               <input type="button" value="Login" id="btn">
                <label for="chk2" id="btm">Sign up here</label>
            </form>
        </div>
        <div class="d"></div>
        <div class="e"></div>
    </div>
</body>
</html>
